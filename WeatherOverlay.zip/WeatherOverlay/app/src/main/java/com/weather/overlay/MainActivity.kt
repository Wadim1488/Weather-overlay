package com.weather.overlay
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    val wv = WebView(this)
    wv.settings.javaScriptEnabled = true
    wv.addJavascriptInterface(Bridge(), "Android")
    wv.loadUrl("file:///android_asset/menu.html")
    setContentView(wv)
  }
  inner class Bridge {
    @JavascriptInterface fun start(w: String, t: Int, a: Float, men: Int, trees: Int, ch: String, thr: Boolean) {
      if (!Settings.canDrawOverlays(this@MainActivity)) {
        runOnUiThread { Toast.makeText(this@MainActivity, "Разреши «Поверх других окон» и нажми Запустить снова", Toast.LENGTH_LONG).show() }
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return
      }
      val q = "?w=$w&t=$t&a=$a&men=$men&trees=$trees&ch=$ch&thr=${if (thr) 1 else 0}"
      startForegroundService(Intent(this@MainActivity, OverlayService::class.java).putExtra("q", q).putExtra("thr", thr))
    }
    @JavascriptInterface fun stop() { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
  }
}
