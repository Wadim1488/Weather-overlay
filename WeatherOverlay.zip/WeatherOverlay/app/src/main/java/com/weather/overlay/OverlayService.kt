package com.weather.overlay
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class OverlayService : Service() {
  private var wv: WebView? = null
  private var strip: WebView? = null
  private var throwOn = false
  private var q = ""
  private lateinit var wm: WindowManager
  private val ui = Handler(Looper.getMainLooper())

  inner class Bridge {
    @JavascriptInterface fun fire(x: Float, vx: Float, vy: Float, g: Float) {
      ui.post { wv?.evaluateJavascript("fire($x,$vx,$vy,$g)", null) }
    }
  }

  override fun onBind(i: Intent?): IBinder? = null

  private fun notif(): Notification {
    val ch = "weather"
    getSystemService(NotificationManager::class.java)
      .createNotificationChannel(NotificationChannel(ch, "Погода", NotificationManager.IMPORTANCE_LOW))
    fun pi(code: Int, act: String) = PendingIntent.getService(this, code,
      Intent(this, OverlayService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE)
    return Notification.Builder(this, ch)
      .setContentTitle(if (throwOn) "Внизу экрана куча для бросков" else "Погода работает")
      .setSmallIcon(android.R.drawable.ic_menu_compass)
      .addAction(Notification.Action.Builder(null, if (throwOn) "Спрятать кучу" else "Бросать", pi(1, "TOGGLE")).build())
      .addAction(Notification.Action.Builder(null, "Стоп", pi(0, "STOP")).build())
      .build()
  }

  private fun fg() {
    val n = notif()
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
  }

  private fun showStrip() {
    hideStrip()
    val d = resources.displayMetrics.density
    val w = Uri.parse("http://x/$q").getQueryParameter("w") ?: "winter"
    val v = WebView(this)
    v.setBackgroundColor(Color.TRANSPARENT)
    v.settings.javaScriptEnabled = true
    v.addJavascriptInterface(Bridge(), "Android")
    v.loadUrl("file:///android_asset/strip.html?w=$w")
    val p = WindowManager.LayoutParams(
      WindowManager.LayoutParams.MATCH_PARENT, (100 * d).toInt(),
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
      PixelFormat.TRANSLUCENT)
    p.gravity = Gravity.BOTTOM
    p.y = (36 * d).toInt()
    wm.addView(v, p)
    strip = v
  }

  private fun hideStrip() {
    strip?.let { wm.removeView(it); it.destroy() }
    strip = null
  }

  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    when (i?.action) {
      "STOP" -> { stopSelf(); return START_NOT_STICKY }
      "TOGGLE" -> {
        if (wv == null) { stopSelf(); return START_NOT_STICKY }
        throwOn = !throwOn
        if (throwOn) showStrip() else hideStrip()
        wv!!.evaluateJavascript("setThrow($throwOn)", null)
        fg(); return START_NOT_STICKY
      }
    }
    throwOn = i?.getBooleanExtra("thr", false) ?: false
    q = i?.getStringExtra("q") ?: ""
    fg()
    if (wv == null) {
      wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
      val v = WebView(this)
      v.setBackgroundColor(Color.TRANSPARENT)
      v.settings.javaScriptEnabled = true
      val p = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
          WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT)
      wm.addView(v, p)
      wv = v
    }
    wv?.loadUrl("file:///android_asset/overlay.html$q")
    if (throwOn) showStrip() else hideStrip()
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    hideStrip()
    wv?.let { wm.removeView(it); it.destroy() }
    wv = null
    super.onDestroy()
  }
}
